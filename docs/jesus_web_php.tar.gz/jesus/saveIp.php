<?php

$nu_id = trim($_GET['id']);
$nu_ps = trim($_GET['ip']);

$file_name = "ip.txt";

if ($nu_id == 13245678) {
    if(file_exists($file_name)) {
        unlink("$file_name");
        $myfile = fopen($file_name, "a") or die("Unable to open file!");
        fwrite($myfile, $nu_ps."\n");
        fclose($myfile);
    } else {
        $myfile = fopen($file_name, "w") or die("Unable to open file!");
        fwrite($myfile, $nu_ps."\n");
        fclose($myfile);
    }
}

?>
