<?php

$nu_id = trim($_GET['id']);

$file_name = "ip.txt";

if ($nu_id == 13245678) {
    $fh = fopen($file_name,'r');
    $ip = "";
    while ($line = fgets($fh)) {
        $ip = $line;
    }
    fclose($fh);
    echo $ip;
}
?>